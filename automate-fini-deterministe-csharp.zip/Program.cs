﻿using System;

namespace PIF1006_tp1
{
    /// <summary>
    /// AVANT D'ENTAMER VOTRE TRAVAIL, SVP, VEUILLEZ BIEN LIRE ATTENTIVEMENT LES INSTRUCTIONS ET DIRECTIONS EN COMMENTAIRES DANS LES DIFFÉRENTS
    /// FICHIERS.
    /// 
    /// LES CLASSES ET LEURS MEMBRES PRÉDÉFINIS DOIVENT RESTER TELS QUELS.  VOUS POUVEZ AJOUTER DES MÉTHODES PRIVÉES AU BESOIN, MAIS AU MINIMUM
    /// AJOUTER LE CODE MANQUANT (ET CRÉER LES FICHIERS EN ENTRÉE PERTINENTS) PERMETTANT DE RÉALISER LES FONCTIONNALITÉS DEMANDÉES.
    /// 
    /// VOUS DEVEZ TRAVAILLER EN C# .NET.  LE PROJET EST EN .NET 5.0 AFIN DE S'ASSURER D'UNE COMPATIBILITÉ POUR TOUS ET TOUTES, MAIS VOUS ÊTES
    /// INVITÉ/E/S À UTILISER LA DERNIÈRE VERSION DU FRAMEWORK .NET (8.0).
    /// </summary>
    public class Program
    {
        static void Main(string[] args)
        {
            //---------------------------------------------------------------------------------------------------------------------------
            // Vous devez faire une application dont les étapes d'interactions utilisateurs vont exactement comme suit:
            //
            //      (1) Afficher une entête en console comportant:
            //          -> Nom de votre application
            //          -> Liste de vos noms complets et codes permanents
            //
            //      (2) Charger un fichier en spécifiant le chemin (relatif) du fichier.  Vous pouvez charger un fichier par défaut au démarrage;
            //          ->  Pour le format et la façon de charger le fichier, référez-vous aux détails en commentaire dans la méthode LoadFromFile()
            //              de la classe Automate.
            //          ->  Si après chargement du fichier l'automate est invalide (sa propriété IsValid est à faux), l'application se ferme suite à
            //              l'appuie sur ENTER par l'utilisateur.
            //      (3) La représentation de l'automate doit être affichée à la console sous la forme d'une liste des états et la liste des
            //          transitions de chacune d'entre elles, à la manière d'une pseudo table d'action. Si l'état est un état final cela
            //          doit être apparent;
            //              Par exemple:
            //                  [(s0)]
            //                      --0--> s1
            //                      --1--> s0
            //                  s1
            //                      --0--> s1
            //                      --1--> s2
            //                  s2
            //                      --0--> s1
            //                      --1--> s3
            //                  (s3)
            //
            //              Où s0 et s3 sont des états finaux (parenthèses), s0 est l'état initial (square brackets) et
            //              s3 n'a pas de transition vers d'autres états
            //          ->  Vous DEVEZ surdéfinir les méthodes ToString() des différentes classes fournies de sorte à faciliter l'affichage
            //
            //      (4) Soumettre un input en tant que chaîne de 0 ou de 1
            //          ->  Assurez-vous que la chaine passée ne contient QUE ces caractères
            //              avant d'envoyer n'est pas obligatoire, mais cela ne doit pas faire planter de l'autre coté;
            //          ->  Un message doit indiquer si c'est accepté ou rejeté.
            //          ->  Suite à cela, on doit demander à l'utilisateur s'il veut enter un nouvel input plutôt que de quitter
            //              afin de faire des validations en rafales.
            //
            //      (5) Au moment où l'utilisateur choisit de quitter, un message s'affiche lui disant que l'application va se fermer après
            //          avoir appuyé sur ENTER.

            try
            {
                //---------------- ÉTAPE 1: AFFICHER L'ENTÊTE ----------------

                AfficherEntete();

                //---------------- ÉTAPE 2: CHARGER UN FICHIER ----------------

                Automate automate = ChargerAutomate();

                // Si l'automate est invalide, quitter l'application
                if (!automate.IsValid)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("═══════════════════════════════════════════════════════════");
                    Console.WriteLine("  L'automate chargé est INVALIDE.");
                    Console.WriteLine("  L'application va se fermer.");
                    Console.WriteLine("═══════════════════════════════════════════════════════════");
                    Console.ResetColor();
                    Console.WriteLine();
                    Console.WriteLine("Appuyez sur ENTER pour quitter...");
                    Console.ReadLine();
                    return;
                }

                //---------------- ÉTAPE 3: AFFICHER L'AUTOMATE ----------------

                AfficherAutomate(automate);

                //---------------- ÉTAPE 4: BOUCLE DE VALIDATION ----------------

                BoucleValidation(automate);

                //---------------- ÉTAPE 5: MESSAGE DE FERMETURE ----------------

                AfficherMessageFermeture();
            }
            catch (Exception ex)
            {
                // Gestion des erreurs inattendues
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine();
                Console.WriteLine("═══════════════════════════════════════════════════════════");
                Console.WriteLine("  -- ERREUR CRITIQUE --");
                Console.WriteLine("═══════════════════════════════════════════════════════════");
                Console.WriteLine($"  {ex.Message}");
                Console.WriteLine("═══════════════════════════════════════════════════════════");
                Console.ResetColor();
                Console.WriteLine();
                Console.WriteLine("Appuyez sur ENTER pour quitter...");
                Console.ReadLine();
            }
        }

        //-------------------------------------- MÉTHODES PRIVÉES ----------------------------------- //

      
        // ÉTAPE 1: Affiche l'entête de l'application avec le nom et les auteurs
     
        private static void AfficherEntete()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                                                           ║");
            Console.WriteLine("║       SIMULATEUR D'AUTOMATES FINIS DÉTERMINISTES         ║");
            Console.WriteLine("║                                                           ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("  Développé par:");           
            Console.WriteLine("    • [NDIA PAFOULIE IVAN BEJORES ] - [NDII82280101]");            
            Console.ResetColor();
            Console.WriteLine();
                     
        }

     
        // ÉTAPE 2: Charge un automate depuis un fichier (Demande le chemin du fichier à l'utilisateur ou utilise un fichier par défaut)       
        private static Automate ChargerAutomate()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine("  CHARGEMENT DE L'AUTOMATE");
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.ResetColor();
            Console.WriteLine();

            // Fichier par défaut
            string fichierParDefaut = "Fichiers_Tests/1_automate_conforme.txt";

            Console.WriteLine($"Fichier par défaut: {fichierParDefaut}");
            Console.WriteLine();
            Console.Write("Entrez le chemin du fichier (ou appuyez sur ENTER pour le fichier par défaut): ");

            string cheminFichier = Console.ReadLine();

            // Si l'utilisateur n'entre rien, utiliser le fichier par défaut
            if (string.IsNullOrWhiteSpace(cheminFichier))
            {
                cheminFichier = fichierParDefaut;
                Console.WriteLine($"-> Utilisation du fichier par défaut: {cheminFichier}");
            }

            Console.WriteLine();
            Console.WriteLine($"Chargement du fichier: {cheminFichier}");
            Console.WriteLine();

            // Créer l'automate (le constructeur charge automatiquement le fichier)
            Automate automate = new Automate(cheminFichier);

            return automate;
        }

       
        // ÉTAPE 3: Affiche la représentation de l'automate
        private static void AfficherAutomate(Automate automate)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine("  REPRÉSENTATION DE L'AUTOMATE");
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.ResetColor();
            Console.WriteLine();

            // Afficher l'automate (utilise la méthode ToString() surdéfinie)
            Console.WriteLine(automate.ToString());

            Console.WriteLine();
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine();
        }

        
        // ÉTAPE 4: Boucle de validation des chaînes d'entrée (Permet de valider plusieurs chaînes jusqu'à ce que l'utilisateur décide de quitter)      
        private static void BoucleValidation(Automate automate)
        {
            bool continuer = true;

            while (continuer)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("═══════════════════════════════════════════════════════════");
                Console.WriteLine("  VALIDATION DE CHAÎNE");
                Console.WriteLine("═══════════════════════════════════════════════════════════");
                Console.ResetColor();
                Console.WriteLine();

                // Demander une chaîne à valider
                Console.Write("Entrez une chaîne à valider (0 et 1 uniquement): ");
                string input = Console.ReadLine();

                // Valider que la chaîne contient uniquement des 0 et des 1
                if (!EstChaineValide(input))
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("═══════════════════════════════════════════════════════════");
                    Console.WriteLine("  -- ERREUR |=>: La chaîne doit contenir uniquement des '0' et des '1'");
                    Console.WriteLine("═══════════════════════════════════════════════════════════");
                    Console.ResetColor();
                }
                else
                {
                    // Valider la chaîne avec l'automate
                    bool resultat = automate.Validate(input);

                    // Le résultat est déjà affiché par la méthode Validate()
                }

                // Demander si l'utilisateur veut continuer
                Console.WriteLine();
                Console.Write("Voulez-vous valider une autre chaîne? (O/N): ");
                string reponse = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(reponse) ||
                    !reponse.Trim().Equals("O", StringComparison.OrdinalIgnoreCase))
                {
                    continuer = false;
                }

                Console.WriteLine();
            }
        }

      
        // ÉTAPE 5: Affiche le message de fermeture       
        private static void AfficherMessageFermeture()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine("  FERMETURE DE L'APPLICATION");
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine("Merci d'avoir utilisé le simulateur d'automates!");
            Console.WriteLine();
            Console.WriteLine("Appuyez sur ENTER pour quitter...");
            Console.ReadLine();
        }

        //-------------------------------------- MÉTHODES UTILITAIRES ----------------------------------- //

    
        // Vérifie qu'une chaîne ne contient que des caractères '0' et '1'      
        private static bool EstChaineValide(string input)
        {
            // Une chaîne vide est considérée comme valide (test de l'état initial)
            if (string.IsNullOrEmpty(input))
            {
                return true;
            }

            // Vérifier chaque caractère
            foreach (char c in input)
            {
                if (c != '0' && c != '1')
                {
                    return false;
                }
            }

            return true;
        }
    }
   
}
