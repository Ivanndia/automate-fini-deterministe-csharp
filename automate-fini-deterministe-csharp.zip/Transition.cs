﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIF1006_tp1
{
   
    /// <summary>
    /// Une transition représente un tuple (input, nouvel état transité)
    /// </summary>
    public class Transition
    {
        public char Input { get; set; }
        public State TransiteTo { get; set; }

        //-------------------------------------- CONSTRUCTEUR ----------------------------------- //
        public Transition(char input, State transiteTo)
        {
            // Validation des paramètres
            if (transiteTo == null)
            {
                throw new ArgumentNullException(nameof(transiteTo),
                    "L'état de destination ne peut pas être null.");
            }
            Input = input;
            TransiteTo = transiteTo;

        }
        //-------------------------------------- MÉTHODE TOSTRING ----------------------------------- //
        public override string ToString()
        {
            return $"--{Input}--> {TransiteTo.Name}";
        }

        //-------------------------------------- MÉTHODES UTILITAIRES ----------------------------------- //

        // Retourne une description détaillée de la transition (pour débogage)      
        public string ToDetailedString()
        {
            return $"Transition sur '{Input}' vers l'état '{TransiteTo.Name}'";
        }

        // Vérifie si cette transition correspond à un symbole donné
        public bool MatchesSymbol(char symbol)
        {
            return Input == symbol;
        }

        // Compare deux transitions (basé sur l'input et l'état destination)
        public override bool Equals(object obj)
        {
            if (obj is Transition other)
            {
                return Input == other.Input &&
                       TransiteTo.Equals(other.TransiteTo);
            }
            return false;
        }

        // Hash code basé sur l'input et l'état destination
        public override int GetHashCode()
        {
            return HashCode.Combine(Input, TransiteTo.Name);
        }
    }
}
