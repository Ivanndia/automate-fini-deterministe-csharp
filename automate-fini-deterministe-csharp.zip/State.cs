﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIF1006_tp1
{
    /// <summary>
    /// Un état a un nom (p.ex. "s0", "s1", ou peu importe), peut être un état final, et peut transiter vers d'autres états
    /// selon un input lu (on a donc une liste de transitions, où chaque transition est un tuple (input, nouvel état) 
    /// </summary>
    public class State
    {
        public bool IsFinal {get; private set;}
        public string Name { get; private set; }
        public List<Transition> Transitions { get; private set; }

        //-------------------------------------- PROPRIÉTÉ  ----------------------------------- //

        // Indique si cet état est l'état initial de l'automate (Nécessaire pour l'affichage et la gestion de l'automate)
        public bool IsInitial { get; set; }

        //-------------------------------------- CONSTRUCTEUR ----------------------------------- //
        public State (string name, bool isFinal)
        {
            // Validation du nom
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Le nom de l'état ne peut pas être vide.", nameof(name));
            }

            Name = name;
            IsFinal = isFinal;
            IsInitial = false;
            Transitions = new List<Transition>();
        }

        //-------------------------------------- MÉTHODES PUBLIQUES ----------------------------------- //

        // METHODE AddTransition: Ajoute une transition à cet état
        public void AddTransition(Transition transition)
        {
            if (transition == null)
            {
                throw new ArgumentNullException(nameof(transition), "La transition ne peut pas être null.");
            }
            Transitions.Add(transition);
        }

        // Recherche une transition pour un symbole donné / Retourne la première transition trouvée (automate déterministe)
        public Transition GetTransition(char input)
        {
            return Transitions.FirstOrDefault(t => t.Input == input);
        }

        // Retourne toutes les transitions pour un symbole donné / Utilisé pour détecter le non-déterminisme
        public List<Transition> GetAllTransitions(char input)
        {
            return Transitions.Where(t => t.Input == input).ToList();
        }

        //-------------------------------------- MÉTHODE TOSTRING  ----------------------------------- //

        public override string ToString()
        {
            var sb = new StringBuilder();

            // Première ligne: nom de l'état avec marqueurs
            string stateName = Name;

            // Ajouter les marqueurs selon le type d'état
            if (IsInitial && IsFinal)
            {
                sb.AppendLine($"[({stateName})]");  // État initial ET final
            }
            else if (IsInitial)
            {
                sb.AppendLine($"[{stateName}]");     // État initial seulement
            }
            else if (IsFinal)
            {
                sb.AppendLine($"({stateName})");     // État final seulement
            }
            else
            {
                sb.AppendLine(stateName);            // État normal
            }

            // Afficher les transitions (triées par symbole pour cohérence)
            var transitionsTriees = Transitions.OrderBy(t => t.Input).ToList();
            foreach (var transition in transitionsTriees)
            {
                sb.AppendLine($"    --{transition.Input}--> {transition.TransiteTo.Name}");
            }

            return sb.ToString().TrimEnd(); // Enlever le dernier saut de ligne
        }

        //-------------------------------------- MÉTHODES UTILITAIRES ----------------------------------- //

        // Vérifie si cet état a des transitions
        public bool HasTransitions()
        {
            return Transitions.Count > 0;
        }

        // Retourne le nombre de transitions depuis cet état
        public int TransitionCount()
        {
            return Transitions.Count;
        }

        // Compare deux états (basé sur le nom)
        public override bool Equals(object obj)
        {
            if (obj is State other)
            {
                return Name.Equals(other.Name, StringComparison.OrdinalIgnoreCase);
            }
            return false;
        }

        // Hash code basé sur le nom
        public override int GetHashCode()
        {
            return Name.ToLowerInvariant().GetHashCode();
        }
    }
}
