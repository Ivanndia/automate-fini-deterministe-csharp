﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIF1006_tp1
{
    public class Automate
    {
        public State InitialState { get; private set; }
        public State CurrentState { get; private set; }
        public List<State> States { get; private set; }
        public bool IsValid { get; private set; }


        //-------------------------------------- PROPRIÉTÉS  ----------------------------------- //

        
        // Liste des messages d'erreur/avertissement générés lors du chargement       
        private List<string> _messages;
       
        // Alphabet de l'automate (déduit des transitions)        
        private HashSet<char> _alphabet;

        //-------------------------------------- CONSTRUCTEUR ----------------------------------- //

        // Constructeur de l'automate qui charge un fichier
        public Automate(string filePath)
        {
            States = new List<State>();

            _messages = new List<string>();
            _alphabet = new HashSet<char>();
            IsValid = false;

            LoadFromFile(filePath);
        }

        //-------------------------------------- MÉTHODE LOADFROMFILE ----------------------------------- //
        private void LoadFromFile(string filePath)
        {
            try
            {
                //---------------- ÉTAPE 1: VÉRIFICATION DU FICHIER ----------------

                // Vérifier que le fichier existe
                if (!File.Exists(filePath))
                {
                    _messages.Add($"ERREUR: Le fichier '{filePath}' n'existe pas.");
                    IsValid = false;
                    AfficherMessages();
                    return;
                }

                //---------------- ÉTAPE 2: LECTURE DU FICHIER ----------------

                string[] lignes = File.ReadAllLines(filePath);
                int numeroLigne = 0;

                foreach (string ligne in lignes)
                {
                    numeroLigne++;

                    // Ignorer les lignes vides ou commentaires
                    string ligneTrimmed = ligne.Trim();
                    if (string.IsNullOrWhiteSpace(ligneTrimmed) || ligneTrimmed.StartsWith("#"))
                    {
                        continue;
                    }

                    // Séparer la ligne en tokens
                    string[] tokens = ligneTrimmed.Split(new[] { ' ', '\t' },
                        StringSplitOptions.RemoveEmptyEntries);

                    if (tokens.Length == 0)
                    {
                        continue;
                    }

                    //---------------- TRAITEMENT DES COMMANDES ----------------

                    string commande = tokens[0].ToLower();

                    if (commande == "state")
                    {
                        // Format: state [nom] [estFinal] [estInitial]
                        TraiterLigneEtat(tokens, numeroLigne);
                    }
                    else if (commande == "transition")
                    {
                        // Format: transition [source] [symbole] [destination]
                        TraiterLigneTransition(tokens, numeroLigne);
                    }
                    else
                    {
                        _messages.Add($"Ligne {numeroLigne}: Commande inconnue '{commande}' - ligne ignorée");
                    }
                }

                //---------------- ÉTAPE 3: VALIDATION DE L'AUTOMATE ----------------

                ValidateAutomate();

                //---------------- ÉTAPE 4: AFFICHAGE DES MESSAGES ----------------

                AfficherMessages();
            }
            catch (Exception ex)
            {
                _messages.Add($"ERREUR lors du chargement: {ex.Message}");
                IsValid = false;
                AfficherMessages();
            }
        }


        //-------------------------------------- MÉTHODES PRIVÉES DE TRAITEMENT ----------------------------------- //

        // METHODE TraiterLigneEtat: Traite une ligne définissant un état / Format: state [nom] [estFinal:0/1] [estInitial:0/1]

        private void TraiterLigneEtat(string[] tokens, int numeroLigne)
        {
            // Vérifier le nombre d'arguments
            if (tokens.Length < 4)
            {
                _messages.Add($"Ligne {numeroLigne}: Format incorrect pour 'state' - attendu: state [nom] [estFinal] [estInitial]");
                return;
            }

            string nomEtat = tokens[1];
            string estFinalStr = tokens[2];
            string estInitialStr = tokens[3];

            // Valider les valeurs booléennes (0 ou 1)
            if (!int.TryParse(estFinalStr, out int estFinalInt) ||
                !int.TryParse(estInitialStr, out int estInitialInt))
            {
                _messages.Add($"Ligne {numeroLigne}: Les valeurs estFinal et estInitial doivent être 0 ou 1");
                return;
            }

            bool estFinal = estFinalInt == 1;
            bool estInitial = estInitialInt == 1;

            // Vérifier que l'état n'existe pas déjà
            if (States.Any(s => s.Name.Equals(nomEtat, StringComparison.OrdinalIgnoreCase)))
            {
                _messages.Add($"Ligne {numeroLigne}: L'état '{nomEtat}' existe déjà - ligne ignorée");
                return;
            }

            // Créer et ajouter l'état
            State nouvelEtat = new State(nomEtat, estFinal)
            {
                IsInitial = estInitial
            };
            States.Add(nouvelEtat);

            // Définir l'état initial
            if (estInitial)
            {
                if (InitialState != null)
                {
                    _messages.Add($"Ligne {numeroLigne}: AVERTISSEMENT - Un état initial existe déjà ({InitialState.Name}). " +
                                 $"L'état '{nomEtat}' ne sera pas défini comme initial.");
                    nouvelEtat.IsInitial = false;
                }
                else
                {
                    InitialState = nouvelEtat;
                }
            }
        }

        // METHODE TraiterLigneTransition: Traite une ligne définissant une transition / Format: transition [étatSource] [symbole] [étatDestination]
        private void TraiterLigneTransition(string[] tokens, int numeroLigne)
        {
            // Vérifier le nombre d'arguments
            if (tokens.Length < 4)
            {
                _messages.Add($"Ligne {numeroLigne}: Format incorrect pour 'transition' - attendu: transition [source] [symbole] [destination]");
                return;
            }

            string nomEtatSource = tokens[1];
            string symboleStr = tokens[2];
            string nomEtatDest = tokens[3];

            // Valider le symbole (doit être un seul caractère)
            if (symboleStr.Length != 1)
            {
                _messages.Add($"Ligne {numeroLigne}: Le symbole doit être un seul caractère - ligne ignorée");
                return;
            }

            char symbole = symboleStr[0];

            // Rechercher les états
            State etatSource = States.FirstOrDefault(s =>
                s.Name.Equals(nomEtatSource, StringComparison.OrdinalIgnoreCase));
            State etatDest = States.FirstOrDefault(s =>
                s.Name.Equals(nomEtatDest, StringComparison.OrdinalIgnoreCase));

            // Vérifier que les états existent
            if (etatSource == null)
            {
                _messages.Add($"Ligne {numeroLigne}: État source '{nomEtatSource}' inexistant - transition ignorée");
                return;
            }

            if (etatDest == null)
            {
                _messages.Add($"Ligne {numeroLigne}: État destination '{nomEtatDest}' inexistant - transition ignorée");
                return;
            }

            // Créer et ajouter la transition
            Transition nouvelleTransition = new Transition(symbole, etatDest);
            etatSource.AddTransition(nouvelleTransition);

            // Ajouter le symbole à l'alphabet
            _alphabet.Add(symbole);
        }


        // Methode ValidateAutomate: Valide la structure de l'automate après chargement
        private void ValidateAutomate()
        {
            bool isValid = true;

            //---------------- TEST 1: Au moins un état ----------------

            if (States.Count == 0)
            {
                _messages.Add("-- ERREUR =>: L'automate ne contient aucun état.");
                isValid = false;
            }

            //---------------- TEST 2: État initial existe ----------------

            if (InitialState == null)
            {
                _messages.Add("-- ERREUR =>: L'automate n'a pas d'état initial.");
                isValid = false;
            }

            //---------------- TEST 3: Déterminisme ----------------------

            // Vérifier qu'il n'y a pas plusieurs transitions pour un même (état, symbole)
            foreach (State state in States)
            {
                // Grouper les transitions par symbole
                var transitionsGroupees = state.Transitions.GroupBy(t => t.Input);

                foreach (var groupe in transitionsGroupees)
                {
                    if (groupe.Count() > 1)
                    {
                        _messages.Add($"-- ERREUR =>: L'automate n'est pas déterministe. " +
                                     $"L'état '{state.Name}' a {groupe.Count()} transitions pour le symbole '{groupe.Key}'.");
                        isValid = false;
                    }
                }
            }

            IsValid = isValid;
        }


        // METHODE AfficherMessages: Affiche tous les messages (erreurs et avertissements) en console 
        private void AfficherMessages()
        {
            if (_messages.Count == 0)
            {
                return;
            }

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine("  MESSAGES DE CHARGEMENT");
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.ResetColor();

            foreach (string message in _messages)
            {
                if (message.Contains("--- ERREUR ---"))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                else if (message.Contains("*** AVERTISSEMENT ***"))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                }

                Console.WriteLine($"  {message}");
                Console.ResetColor();
            }

            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine();
        }

        //-------------------------------------- MÉTHODE VALIDATE  ----------------------------------- //
        public bool Validate(string input)
        {
            //---------------- ÉTAPE 1: RÉINITIALISATION ----------------

            Reset();

            //---------------- ÉTAPE 2: VALIDATION DE L'INPUT ----------------
           
            // Vérifier que l'input n'est pas null ou vide
            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine();
                Console.WriteLine("───────────────────────────────────────────────────────────");
                Console.Write($"  Chaîne vide - État initial: {CurrentState.Name}");

                if (CurrentState.IsFinal)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" (ÉTAT ACCEPTEUR)");
                    Console.WriteLine();
                    Console.WriteLine("  YES --> CHAÎNE ACCEPTÉE");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" (ÉTAT NON-ACCEPTEUR)");
                    Console.WriteLine();
                    Console.WriteLine("  NO |=> CHAÎNE REJETÉE");
                    Console.ResetColor();
                }
                Console.WriteLine("═══════════════════════════════════════════════════════════");

                return CurrentState.IsFinal;
            }

            //----------------ÉTAPE 3: AFFICHAGE DE L'EN-TÊTE ---------------- 

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine("  DÉROULEMENT DE LA VALIDATION");
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.ResetColor();
            Console.WriteLine($"  Chaîne à valider: \"{input}\"");
            Console.WriteLine($"  État initial: {CurrentState.Name}");
            Console.WriteLine("───────────────────────────────────────────────────────────");
            Console.WriteLine();

            //---------------- ÉTAPE 4: TRAITEMENT CARACTÈRE PAR CARACTÈRE ----------------

            int position = 0;
            foreach (char symbole in input)
            {
                position++;

                // Afficher l'état actuel et le symbole lu
                Console.Write($"  [{CurrentState.Name}] --{symbole}--> ");

                // Rechercher une transition pour ce symbole
                Transition transition = CurrentState.GetTransition(symbole);

                if (transition == null)
                {
                    // Aucune transition trouvée
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("(AUCUNE TRANSITION)");
                    Console.ResetColor();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"  *=> REJETÉ à la position {position}: aucune transition pour '{symbole}' depuis l'état '{CurrentState.Name}'");
                    Console.ResetColor();
                    Console.WriteLine("═══════════════════════════════════════════════════════════");
                    return false;
                }

                // Effectuer la transition
                CurrentState = transition.TransiteTo;

                // Afficher le nouvel état
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"{CurrentState.Name}");
                Console.ResetColor();
            }

            //---------------- ÉTAPE 5: VÉRIFICATION DE L'ÉTAT FINAL ----------------

            Console.WriteLine();
            Console.WriteLine("───────────────────────────────────────────────────────────");
            Console.Write($"  État final: {CurrentState.Name}");

            bool estAccepte = CurrentState.IsFinal;

            if (estAccepte)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(" (ÉTAT ACCEPTEUR)");
                Console.WriteLine();
                Console.WriteLine("  YES --> CHAÎNE ACCEPTÉE");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" (ÉTAT NON-ACCEPTEUR)");
                Console.WriteLine();
                Console.WriteLine("  NO |=>  CHAÎNE REJETÉE");
                Console.ResetColor();
            }

            Console.WriteLine("═══════════════════════════════════════════════════════════");

            return estAccepte;
        }


        //-------------------------------------- MÉTHODE RESET  ----------------------------------- //

        // Réinitialise l'automate avant une validation / remet l'état courant à l'état initial
        public void Reset()
        {
            CurrentState = InitialState;
        }

        //-------------------------------------- MÉTHODE TOSTRING  ----------------------------------- //

        // Retourne une représentation textuelle de l'automate / Affiche tous les états et leurs transitions
        public override string ToString()
        {
            var sb = new StringBuilder();

            // Trier les états: état initial en premier, puis alphabétique
            var etatsOrdonnes = States.OrderBy(s => s.IsInitial ? 0 : 1)
                                      .ThenBy(s => s.Name)
                                      .ToList();

            foreach (State state in etatsOrdonnes)
            {
                sb.AppendLine(state.ToString());
            }

            return sb.ToString().TrimEnd();
        }

        //-------------------------------------- MÉTHODES UTILITAIRES ----------------------------------- //

        // METHODE ToDetailedString: Retourne une description détaillée de l'automate avec statistiques
        public string ToDetailedString()
        {
            var sb = new StringBuilder();

            sb.AppendLine("═══════════════════════════════════════════════════════════");
            sb.AppendLine("  REPRÉSENTATION DE L'AUTOMATE");
            sb.AppendLine("═══════════════════════════════════════════════════════════");
            sb.AppendLine();
            sb.AppendLine($"  Nombre d'états       : {States.Count}");
            sb.AppendLine($"  État initial         : {(InitialState != null ? InitialState.Name : "AUCUN")}");
            sb.AppendLine($"  États finaux         : {States.Count(s => s.IsFinal)}");
            sb.AppendLine($"  Nombre de transitions: {States.Sum(s => s.TransitionCount())}");
            sb.AppendLine($"  Alphabet             : {{{string.Join(", ", _alphabet.OrderBy(c => c))}}}");
            sb.AppendLine($"  Valide               : {(IsValid ? "OUI" : "NON")}");
            sb.AppendLine();
            sb.AppendLine("───────────────────────────────────────────────────────────");
            sb.AppendLine("  ÉTATS ET TRANSITIONS");
            sb.AppendLine("───────────────────────────────────────────────────────────");
            sb.AppendLine();
            sb.AppendLine(ToString());
            sb.AppendLine("═══════════════════════════════════════════════════════════");

            return sb.ToString();
        }


    }
}
